﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace JellyCube
{
    public class Box_Producer : MonoBehaviour
    {
        public Side side_Presets;

        public enum Side
        {
            Left,
            Right,
            Up,
            Down
        }

        [SerializeField]
        public GameObject box;

        private float spacing;
        private Vector3 pos;
        private GameObject obj;

        [SerializeField]
        public int box_counter = 0; 
        public Text box_counter_text;

        [SerializeField]
        public Material[] mats;

        GameObject endpos;
        public GameObject endpos_obj;

        // Start is called before the first frame update
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {
            box_counter_text.text = ""+box_counter;
        }

        void CheckPresets()
        {
            switch (side_Presets)
            {
                case Side.Left:
                    //spacing += -1;
                    
                    pos = new Vector3(-1, 0, 0);

                    obj = Instantiate(box, transform.position, Quaternion.identity) as GameObject;
                    endpos = Instantiate(endpos_obj, transform.position+new Vector3(-1,0,0), Quaternion.identity) as GameObject;

                    //obj.transform.parent = gameObject.transform;
                    //obj.GetComponent<Lerper>().startPos = this.transform;
                    //obj.GetComponent<Lerper>().endPos = endpos.transform;

                    //obj.GetComponent<CubeController>().m_CanControl = true;
                    //obj.tag = "Player";
                    //obj.transform.GetChild(0).tag = "Player";

                    left();

                    //Invoke("Off_Controls", 1f);
                    //if (obj.transform.position == obj.GetComponent<Lerper>().endPos.position) {
                    //    Off_Controls();
                    //}

                    break;
                case Side.Right:
                    pos = new Vector3(1, 0, 0);

                    obj = Instantiate(box, transform.position, Quaternion.identity) as GameObject;
                    endpos = Instantiate(endpos_obj, transform.position + new Vector3(1, 0, 0), Quaternion.identity) as GameObject;

                    right();

                    break;
                case Side.Up:
                    pos = new Vector3(0, 0, 1);

                    obj = Instantiate(box, transform.position, Quaternion.identity) as GameObject;
                    endpos = Instantiate(endpos_obj, transform.position + new Vector3(0, 0, 1), Quaternion.identity) as GameObject;

                    up();

                    break;
                case Side.Down:
                    pos = new Vector3(0, 0, -1);

                    obj = Instantiate(box, transform.position, Quaternion.identity) as GameObject;
                    endpos = Instantiate(endpos_obj, transform.position + new Vector3(0, 0, -1), Quaternion.identity) as GameObject;

                    down();

                    break;
            }
        }

        void Off_Controls()
        {
            //obj.GetComponent<Rigidbody>().useGravity = false;
            //obj.GetComponent<Rigidbody>().isKinematic = true;

            obj.GetComponent<CubeController>().m_CanControl = false;
            obj.tag = "Untagged";
            obj.transform.GetChild(0).tag = "Untagged";
            //obj.GetComponent<Lerper>().enabled = false;
            //obj.GetComponent<ScaleLerper>().enabled = false;
            //obj.GetComponent<Animator>().enabled = false;
        }

        void OnMouseUp()
        {
            if (box_counter > 0)
            {
                CheckPresets();
                box_counter -= 1;
                GameManager.Instance.total_counter -= 1;
            }

            //spacing += -1;
            //Vector3 pos = new Vector3(spacing, 0, 0);
            //GameObject obj = Instantiate(box,pos,Quaternion.identity) as GameObject;
            //obj.transform.position += new Vector3(-1,0,0);
        }

        public void left()
        {
            obj.GetComponent<CubeController>().DoMove(new Vector3(-1, 0, 0));
        }

        public void right()
        {
            obj.GetComponent<CubeController>().DoMove(new Vector3(1, 0, 0));
        }

        public void up()
        {
            obj.GetComponent<CubeController>().DoMove(new Vector3(0, 0, 1));
        }

        public void down()
        {
            obj.GetComponent<CubeController>().DoMove(new Vector3(0, 0, -1));
        }

    }
}

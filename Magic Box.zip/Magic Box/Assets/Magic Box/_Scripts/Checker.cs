﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace JellyCube
{
    public class Checker : MonoBehaviour
    {

        public string m_CubeTag = "Player"; //fill this variable according to the Cube tag

        [HideInInspector]
        public bool m_Success = false;
        public int counter = 0;

        // Start is called before the first frame update
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {

        }

        void OnTriggerEnter(Collider collider)
        {
            print("triggered");
            //check if the cube object has the same tag of this checkpoint var 'cubeTag'
            if (collider.gameObject.tag == m_CubeTag)
            {
                m_Success = true;
                GameManager.Instance.total_counter_count += 1;
                counter += 1;
                //GameManager.Instance.CheckGame();

                print(m_Success);
            }

            if (collider.gameObject.tag == "Finish")
            {
                GameManager.Instance.OnLevelFailed();
            }

         }

        void OnTriggerExit(Collider collider)
        {
            m_Success = false;
            GameManager.Instance.total_counter_count -= 1;
            counter -= 1;
        }
    }
}

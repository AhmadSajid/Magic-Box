﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace JellyCube
{
    public class Box_Producer : MonoBehaviour
    {
        public Side side_Presets;

        public enum Side
        {
            Left,
            Right,
            Up,
            Down,
            Left_Right,
            Left_Up,
            Right_Up,
            Left_Down,
            Right_Down,
            All_sides
        }

        [SerializeField]
        public GameObject box;

        private float spacing;
        private Vector3 pos;
        private GameObject obj;
        private GameObject obj2;
        private GameObject obj3;
        private GameObject obj4;

        [SerializeField]
        public int box_counter = 0; 
        public TextMeshPro box_counter_text;

        [SerializeField]
        public Material[] mats;

        GameObject endpos;
        GameObject endpos2;
        GameObject endpos3;
        GameObject endpos4;
        public GameObject endpos_obj;
        public GameObject endpos_obj2;
        public GameObject endpos_obj3;
        public GameObject endpos_obj4;

        public GameObject box_click_animator;
        private Dictionary<string, float> m_AnimationClipsLength = new Dictionary<string, float>();

        // Start is called before the first frame update
        void Start()
        {
            endpos_obj2 = endpos_obj;
            endpos_obj3 = endpos_obj;
            endpos_obj4 = endpos_obj;
            //foreach (AnimationClip clip in box_click_animator.GetComponent<Animator>().runtimeAnimatorController.animationClips)
            //{
            //    m_AnimationClipsLength.Add(clip.name, clip.length);
            //}
        }

        // Update is called once per frame
        void Update()
        {
            box_counter_text.text = ""+box_counter;
        }

        void CheckPresets()
        {
            switch (side_Presets)
            {
                case Side.Left:
                    //spacing += -1;
                    
                    pos = new Vector3(-1, 0, 0);

                    obj = Instantiate(box, transform.position, Quaternion.identity) as GameObject;
                    endpos = Instantiate(endpos_obj, transform.position+new Vector3(-1,0,0), Quaternion.identity) as GameObject;

                    obj.transform.parent = GameObject.Find("LevelMovement").transform;

                    //obj.GetComponent<Lerper>().startPos = this.transform;
                    //obj.GetComponent<Lerper>().endPos = endpos.transform;

                    //obj.GetComponent<CubeController>().m_CanControl = true;
                    //obj.tag = "Player";
                    //obj.transform.GetChild(0).tag = "Player";

                    left();

                    //Invoke("Off_Controls", 1f);
                    //if (obj.transform.position == obj.GetComponent<Lerper>().endPos.position) {
                    //    Off_Controls();
                    //}

                    break;
                case Side.Right:
                    pos = new Vector3(1, 0, 0);

                    obj = Instantiate(box, transform.position, Quaternion.identity) as GameObject;
                    endpos = Instantiate(endpos_obj, transform.position + new Vector3(1, 0, 0), Quaternion.identity) as GameObject;
                    obj.transform.parent = GameObject.Find("LevelMovement").transform;

                    right();

                    break;
                case Side.Up:
                    pos = new Vector3(0, 0, 1);

                    obj = Instantiate(box, transform.position, Quaternion.identity) as GameObject;
                    endpos = Instantiate(endpos_obj, transform.position + new Vector3(0, 0, 1), Quaternion.identity) as GameObject;
                    obj.transform.parent = GameObject.Find("LevelMovement").transform;

                    up();

                    break;
                case Side.Down:
                    pos = new Vector3(0, 0, -1);

                    obj = Instantiate(box, transform.position, Quaternion.identity) as GameObject;
                    endpos = Instantiate(endpos_obj, transform.position + new Vector3(0, 0, -1), Quaternion.identity) as GameObject;
                    obj.transform.parent = GameObject.Find("LevelMovement").transform;

                    down();

                    break;
                case Side.Left_Right:

                    left_obj();
                    right_obj();

                    break;
                case Side.Left_Down:

                    left_obj();
                    down_obj();

                    break;
                case Side.Left_Up:

                    left_obj();
                    up_obj();

                    break;
                case Side.Right_Up:

                    right_obj();
                    up_obj();

                    break;
                case Side.Right_Down:

                    right_obj();
                    down_obj();

                    break;
                case Side.All_sides:

                    OnAll_Sides();

                    break;
            }
        }

        void Off_Controls()
        {
            //obj.GetComponent<Rigidbody>().useGravity = false;
            //obj.GetComponent<Rigidbody>().isKinematic = true;

            obj.GetComponent<CubeController>().m_CanControl = false;
            obj.tag = "Untagged";
            obj.transform.GetChild(0).tag = "Untagged";
            //obj.GetComponent<Lerper>().enabled = false;
            //obj.GetComponent<ScaleLerper>().enabled = false;
            //obj.GetComponent<Animator>().enabled = false;
        }

        void OnMouseUp()
        {
         
            if (box_counter > 0)
            {
                CheckPresets();
                box_click_animator.GetComponent<Animator>().enabled = true;
                box_counter -= 1;
                GameManager.Instance.total_counter -= 1;
                Invoke("OnBox_Cylinderoff",0.8f);
            }

            //spacing += -1;
            //Vector3 pos = new Vector3(spacing, 0, 0);
            //GameObject obj = Instantiate(box,pos,Quaternion.identity) as GameObject;
            //obj.transform.position += new Vector3(-1,0,0);
        }

        void OnBox_Cylinderoff()
        {
            box_click_animator.GetComponent<Animator>().enabled = false;
        }

        public void left()
        {
            obj.GetComponent<CubeController>().DoMove(new Vector3(-1, 0, 0));
        }

        public void right()
        {
            obj.GetComponent<CubeController>().DoMove(new Vector3(1, 0, 0));
        }

        public void up()
        {
            obj.GetComponent<CubeController>().DoMove(new Vector3(0, 0, 1));
        }

        public void down()
        {
            obj.GetComponent<CubeController>().DoMove(new Vector3(0, 0, -1));
        }

        public void left_obj()
        {
            obj = Instantiate(box, transform.position, Quaternion.identity) as GameObject;
            endpos = Instantiate(endpos_obj, transform.position + new Vector3(-1, 0, 0), Quaternion.identity) as GameObject;

            obj.transform.parent = GameObject.Find("LevelMovement").transform;
            obj.GetComponent<CubeController>().DoMove(new Vector3(-1, 0, 0));
        }

        public void right_obj()
        {
            obj2 = Instantiate(box, transform.position, Quaternion.identity) as GameObject;
            endpos2 = Instantiate(endpos_obj2, transform.position + new Vector3(1, 0, 0), Quaternion.identity) as GameObject;

            obj2.transform.parent = GameObject.Find("LevelMovement").transform;
            obj2.GetComponent<CubeController>().DoMove(new Vector3(1, 0, 0));
        }

        public void up_obj()
        {
            obj3 = Instantiate(box, transform.position, Quaternion.identity) as GameObject;
            endpos3 = Instantiate(endpos_obj3, transform.position + new Vector3(0, 0, 1), Quaternion.identity) as GameObject;
            obj3.transform.parent = GameObject.Find("LevelMovement").transform;
            obj3.GetComponent<CubeController>().DoMove(new Vector3(0, 0, 1));
        }

        public void down_obj()
        {
            obj4 = Instantiate(box, transform.position, Quaternion.identity) as GameObject;
            endpos4 = Instantiate(endpos_obj4, transform.position + new Vector3(0, 0, -1), Quaternion.identity) as GameObject;
            obj4.transform.parent = GameObject.Find("LevelMovement").transform;
            obj4.GetComponent<CubeController>().DoMove(new Vector3(0, 0, -1));
        }

        public void OnAll_Sides()
        {
            left_obj();

            obj2 = Instantiate(box, transform.position, Quaternion.identity) as GameObject;
            endpos2 = Instantiate(endpos_obj2, transform.position + new Vector3(1, 0, 0), Quaternion.identity) as GameObject;
            obj2.transform.parent = GameObject.Find("LevelMovement").transform;
            obj2.GetComponent<CubeController>().DoMove(new Vector3(1, 0, 0));

            obj3 = Instantiate(box, transform.position, Quaternion.identity) as GameObject;
            endpos3 = Instantiate(endpos_obj3, transform.position + new Vector3(0, 0, 1), Quaternion.identity) as GameObject;
            obj3.transform.parent = GameObject.Find("LevelMovement").transform;
            obj3.GetComponent<CubeController>().DoMove(new Vector3(0, 0, 1));

            obj4 = Instantiate(box, transform.position, Quaternion.identity) as GameObject;
            endpos4 = Instantiate(endpos_obj4, transform.position + new Vector3(0, 0, -1), Quaternion.identity) as GameObject;
            obj4.transform.parent = GameObject.Find("LevelMovement").transform;
            obj4.GetComponent<CubeController>().DoMove(new Vector3(0, 0, -1));
        }

    }
}
